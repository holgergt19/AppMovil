import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../view_models/ride_view_model.dart';
import 'ride_tracking_screen.dart';
import '../models/ride_request.dart';

class WaitingForDriverScreen extends StatefulWidget {
  static const String routeName = '/waiting-for-driver';

  const WaitingForDriverScreen({Key? key}) : super(key: key);

  @override
  _WaitingForDriverScreenState createState() => _WaitingForDriverScreenState();
}

class _WaitingForDriverScreenState extends State<WaitingForDriverScreen> {
  @override
  void initState() {
    super.initState();

    // Nos suscribimos al estado del ride activo
    final vm = context.read<RideViewModel>();
    vm.currentRideStream().listen(
      (ride) {
        // Cuando el driver acepte o empiece a moverse, navegamos al tracking
        if (mounted &&
            (ride.status == 'accepted' || ride.status == 'on_the_way')) {
          Navigator.pushReplacementNamed(
            context,
            RideTrackingScreen.routeName,
            arguments: ride as RideRequest,
          );
        }
      },
      onError: (_) {
        // Ignoramos el error "no hay viaje activo" hasta que se cree en Firestore
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Spinner grande
                SizedBox(
                  width: 80,
                  height: 80,
                  child: CircularProgressIndicator(
                    strokeWidth: 6,
                    color: theme.colorScheme.primary,
                  ),
                ),
                const SizedBox(height: 24),

                // Mensaje
                Text(
                  'Buscando un conductor disponible…',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 24),

                // Opción de cancelar
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Cancelar solicitud',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.secondary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
