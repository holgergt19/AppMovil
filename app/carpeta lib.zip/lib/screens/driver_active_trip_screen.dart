import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class DriverActiveTripScreen extends StatefulWidget {
  static const String routeName = '/driver-active-trip';

  final Map<String, dynamic> ride;
  DriverActiveTripScreen({Key? key, required this.ride}) : super(key: key);

  @override
  _DriverActiveTripScreenState createState() => _DriverActiveTripScreenState();
}

class _DriverActiveTripScreenState extends State<DriverActiveTripScreen> {
  late LatLng pickupLatLng;
  late LatLng destinationLatLng;
  GoogleMapController? _mapController;

  @override
  void initState() {
    super.initState();
    final p = widget.ride['pickupLocation'];
    final d = widget.ride['destinationLocation'];
    pickupLatLng = LatLng(
      (p['latitude'] as num).toDouble(),
      (p['longitude'] as num).toDouble(),
    );
    destinationLatLng = LatLng(
      (d['latitude'] as num).toDouble(),
      (d['longitude'] as num).toDouble(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Viaje Activo')),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(target: pickupLatLng, zoom: 14),
        markers: {
          Marker(markerId: const MarkerId('origin'), position: pickupLatLng),
          Marker(
            markerId: const MarkerId('destination'),
            position: destinationLatLng,
          ),
        },
        onMapCreated: (c) => _mapController = c,
      ),
    );
  }
}
