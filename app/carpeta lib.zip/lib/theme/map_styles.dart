const String darkMapStyle = '''
[
  {
    "elementType": "geometry",
    "stylers": [{"color": "#1e1e1e"}]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [{"color": "#ffffff"}]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [{"color": "#2c2c2c"}]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{"color": "#0e0e0e"}]
  }
]
''';
