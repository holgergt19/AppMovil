import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../view_models/driver_view_model.dart';
import '../models/ride_request.dart';

class DriverHomeScreen extends StatefulWidget {
  static const String routeName = DriverViewModel.driverHomeRoute;

  const DriverHomeScreen({Key? key}) : super(key: key);

  @override
  _DriverHomeScreenState createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen> {
  @override
  void initState() {
    super.initState();
    context.read<DriverViewModel>().fetchAvailableRides();
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DriverViewModel>();
    final rides = vm.availableRides;

    return Scaffold(
      appBar: AppBar(title: const Text('Inicio Conductor')),
      body:
          rides.isEmpty
              ? const Center(child: Text('No hay viajes disponibles'))
              : ListView.builder(
                itemCount: rides.length,
                itemBuilder: (_, i) {
                  final r = rides[i];
                  return ListTile(
                    title: Text('Destino: ${r.destinationName}'),
                    subtitle: Text('Usuario: ${r.userName}'),
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        DriverViewModel.driverTripDetailRoute,
                        arguments: r,
                      );
                    },
                  );
                },
              ),
    );
  }
}
