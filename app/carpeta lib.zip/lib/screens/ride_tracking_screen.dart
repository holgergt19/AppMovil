import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../models/ride_request.dart';
import '../services/directions_service.dart';

class RideTrackingScreen extends StatefulWidget {
  static const String routeName = '/ride-tracking';
  final RideRequest rideRequest;

  const RideTrackingScreen({Key? key, required this.rideRequest})
    : super(key: key);

  @override
  _RideTrackingScreenState createState() => _RideTrackingScreenState();
}

class _RideTrackingScreenState extends State<RideTrackingScreen> {
  late GoogleMapController _mapController;
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _rideSub;
  String _status = '';
  int? _etaMinutes;

  @override
  void initState() {
    super.initState();
    _status = widget.rideRequest.status;
    // Marcadores iniciales
    _markers.addAll({
      Marker(
        markerId: const MarkerId('origin'),
        position: widget.rideRequest.pickupLocation,
        infoWindow: const InfoWindow(title: 'Origen'),
      ),
      Marker(
        markerId: const MarkerId('destination'),
        position: widget.rideRequest.dropoffLocation,
        infoWindow: const InfoWindow(title: 'Destino'),
      ),
    });
    // Escuchar actualizaciones de ride
    _listenRideUpdates();
  }

  void _listenRideUpdates() {
    _rideSub = FirebaseFirestore.instance
        .collection('ride_requests')
        .doc(widget.rideRequest.id)
        .snapshots()
        .listen((snap) async {
          final data = snap.data();
          if (data == null) return;
          final status = data['status'] as String? ?? '';
          final gp = data['driverLocation'] as GeoPoint?;
          setState(() => _status = status);

          if (gp != null) {
            final driverPos = LatLng(gp.latitude, gp.longitude);
            // Actualizar marcador de conductor
            _markers.removeWhere((m) => m.markerId.value == 'driver');
            _markers.add(
              Marker(
                markerId: const MarkerId('driver'),
                position: driverPos,
                infoWindow: const InfoWindow(title: 'Conductor'),
                icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueAzure,
                ),
              ),
            );
            // Animar cámara al conductor
            _mapController.animateCamera(CameraUpdate.newLatLng(driverPos));

            if (status == 'on_the_way') {
              // Calcular ETA conductor → usuario
              final result = await DirectionsService().getDirections(
                origin: driverPos,
                destination: widget.rideRequest.pickupLocation,
              );
              setState(
                () =>
                    _etaMinutes =
                        (result.distanceMeters / 1000 / (40 / 60)).ceil(),
              );
              // Dibujar ruta conductor → origen pasajero
              _updatePolyline([driverPos, widget.rideRequest.pickupLocation]);
            } else if (status == 'in_progress') {
              // Ruta pasajero → destino final
              final result = await DirectionsService().getDirections(
                origin: widget.rideRequest.pickupLocation,
                destination: widget.rideRequest.dropoffLocation,
              );
              _updatePolyline([
                widget.rideRequest.pickupLocation,
                widget.rideRequest.dropoffLocation,
              ]);
              setState(
                () =>
                    _etaMinutes =
                        (result.distanceMeters / 1000 / (30 / 60)).ceil(),
              );
            } else if (status == 'completed') {
              // Opcional: navegar a calificación o pantalla final
              Navigator.pop(context);
            }
          }
        });
  }

  void _updatePolyline(List<LatLng> points) {
    _polylines.clear();
    _polylines.add(
      Polyline(
        polylineId: const PolylineId('route'),
        points: points,
        width: 5,
        color: Colors.blueAccent,
      ),
    );
  }

  @override
  void dispose() {
    _rideSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Ajustar bounds al mostrar mapa
    final origin = widget.rideRequest.pickupLocation;
    final dest =
        widget.rideRequest.destinationLat != null
            ? widget.rideRequest.dropoffLocation
            : origin;
    final sw = LatLng(
      min(origin.latitude, dest.latitude),
      min(origin.longitude, dest.longitude),
    );
    final ne = LatLng(
      max(origin.latitude, dest.latitude),
      max(origin.longitude, dest.longitude),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Seguimiento de Viaje')),
      body: Column(
        children: [
          // Mapa ocupa 2/3 de la pantalla
          Expanded(
            flex: 2,
            child: GoogleMap(
              initialCameraPosition: CameraPosition(target: sw, zoom: 12),
              markers: _markers,
              polylines: _polylines,
              onMapCreated: (c) {
                _mapController = c;
                _mapController.animateCamera(
                  CameraUpdate.newLatLngBounds(
                    LatLngBounds(southwest: sw, northeast: ne),
                    60,
                  ),
                );
              },
            ),
          ),
          // Panel de estado y ETA
          Expanded(
            flex: 1,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _status == 'on_the_way'
                        ? 'En camino hacia ti'
                        : _status == 'in_progress'
                        ? 'Viaje en curso'
                        : 'Estado: $_status',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  if (_etaMinutes != null)
                    Text(
                      'ETA: $_etaMinutes min',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
