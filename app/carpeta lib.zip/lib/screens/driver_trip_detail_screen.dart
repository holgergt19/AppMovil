import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';

import '../models/ride_request.dart';
import '../view_models/driver_view_model.dart';

class DriverTripDetailScreen extends StatefulWidget {
  static const String routeName = DriverViewModel.driverTripDetailRoute;
  final RideRequest rideRequest;

  const DriverTripDetailScreen({Key? key, required this.rideRequest})
    : super(key: key);

  @override
  _DriverTripDetailScreenState createState() => _DriverTripDetailScreenState();
}

class _DriverTripDetailScreenState extends State<DriverTripDetailScreen> {
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> _rideStream;
  late GoogleMapController _mapController;
  final Set<Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    // Stream del documento de este viaje
    _rideStream =
        FirebaseFirestore.instance
            .collection('ride_requests')
            .doc(widget.rideRequest.id)
            .snapshots();

    // Marcadores estáticos: origen y destino
    _markers.addAll({
      Marker(
        markerId: const MarkerId('pickup'),
        position: widget.rideRequest.pickupLocation,
        infoWindow: const InfoWindow(title: 'Origen'),
      ),
      Marker(
        markerId: const MarkerId('dropoff'),
        position: widget.rideRequest.dropoffLocation,
        infoWindow: const InfoWindow(title: 'Destino'),
      ),
    });
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.read<DriverViewModel>();

    return Scaffold(
      appBar: AppBar(title: const Text('Detalle del Viaje')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: _rideStream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!.data()!;
          final status = data['status'] as String;
          final GeoPoint? gp = data['driverLocation'] as GeoPoint?;
          final LatLng? driverPos =
              gp != null ? LatLng(gp.latitude, gp.longitude) : null;

          // Actualiza marcador del conductor
          if (driverPos != null) {
            _markers
              ..removeWhere((m) => m.markerId.value == 'driver')
              ..add(
                Marker(
                  markerId: const MarkerId('driver'),
                  position: driverPos,
                  infoWindow: const InfoWindow(title: 'Tu ubicación'),
                ),
              );
          }

          return Column(
            children: [
              // Mapa con todos los marcadores y trazado de ruta
              Expanded(
                flex: 2,
                child: GoogleMap(
                  onMapCreated: (ctrl) => _mapController = ctrl,
                  initialCameraPosition: CameraPosition(
                    target: widget.rideRequest.pickupLocation,
                    zoom: 14,
                  ),
                  markers: _markers,
                  polylines: {
                    Polyline(
                      polylineId: const PolylineId('route'),
                      points: [
                        widget.rideRequest.pickupLocation,
                        if (driverPos != null) driverPos,
                        widget.rideRequest.dropoffLocation,
                      ],
                      width: 5,
                      color: Colors.blue,
                    ),
                  },
                ),
              ),
              const SizedBox(height: 16),
              // Botón de acción según estado actual
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                child: _buildActionButton(vm, status),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildActionButton(DriverViewModel vm, String status) {
    switch (status) {
      case 'pending':
        return ElevatedButton(
          onPressed: () async {
            await vm.acceptRide(widget.rideRequest.id);
          },
          child: const Text('Aceptar viaje'),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
          ),
        );
      case 'accepted':
        return ElevatedButton(
          onPressed: () async {
            await vm.markInProgress(widget.rideRequest.id);
          },
          child: const Text('Marcar llegada'),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
          ),
        );
      case 'in_progress':
        return ElevatedButton(
          onPressed: () async {
            await vm.startOnTheWay(widget.rideRequest.id);
          },
          child: const Text('Iniciar viaje'),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
          ),
        );
      case 'on_the_way':
        return ElevatedButton(
          onPressed: () async {
            await vm.completeTrip(widget.rideRequest.id);
          },
          child: const Text('Completar viaje'),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
            backgroundColor: Colors.green,
          ),
        );
      default:
        return Text('Estado: $status', textAlign: TextAlign.center);
    }
  }
}
