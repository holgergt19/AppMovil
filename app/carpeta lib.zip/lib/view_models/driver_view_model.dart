import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models/ride_request.dart';
import '../services/location_service.dart';

class DriverViewModel extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final LocationService _locationService = LocationService();

  List<RideRequest> _availableRides = [];
  List<RideRequest> get availableRides => _availableRides;

  StreamSubscription<Position>? _positionSub;

  static const String driverHomeRoute = '/driver-home';
  static const String driverTripDetailRoute = '/driver-trip-detail';
  static const String driverActiveTripRoute = '/driver-active-trip';

  /// Carga viajes pendientes
  Future<void> fetchAvailableRides() async {
    final snapshot =
        await _firestore
            .collection('ride_requests')
            .where('status', isEqualTo: 'pending')
            .get();
    _availableRides =
        snapshot.docs.map((d) => RideRequest.fromMap(d.data(), d.id)).toList();
    notifyListeners();
  }

  /// Asigna el viaje a este conductor y marca como 'accepted'
  Future<void> acceptRide(String rideId) async {
    final driverId = FirebaseAuth.instance.currentUser?.uid;
    if (driverId == null) return;
    await _firestore.collection('ride_requests').doc(rideId).update({
      'status': 'accepted',
      'driverId': driverId,
    });
    notifyListeners();
  }

  /// El conductor ha llegado al punto de recogida
  Future<void> markInProgress(String rideId) async {
    // Detenemos cualquier stream previo antes de cambiar estado:
    await _positionSub?.cancel();
    await _firestore.collection('ride_requests').doc(rideId).update({
      'status': 'in_progress',
    });
    notifyListeners();
  }

  /// Empieza a enviar posición y marca 'on_the_way'
  Future<void> startOnTheWay(String rideId) async {
    final ok = await _locationService.requestPermission();
    if (!ok) return;
    _positionSub = _locationService.getPositionStream().listen((pos) {
      _firestore.collection('ride_requests').doc(rideId).update({
        'driverLocation': GeoPoint(pos.latitude, pos.longitude),
        'status': 'on_the_way',
      });
    });
    notifyListeners();
  }

  /// Completa el viaje y limpia posición
  Future<void> completeTrip(String rideId) async {
    await _positionSub?.cancel();
    await _firestore.collection('ride_requests').doc(rideId).update({
      'status': 'completed',
      'driverLocation': null,
    });
    notifyListeners();
  }

  /// Opción para detener tracking sin cambiar estado
  Future<void> stopTracking() async {
    await _positionSub?.cancel();
    _positionSub = null;
  }
}
