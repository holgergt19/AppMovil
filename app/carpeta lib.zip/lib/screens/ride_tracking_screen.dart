import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../view_models/ride_view_model.dart';
import '../models/ride_request.dart';

class RideTrackingScreen extends StatelessWidget {
  static const String routeName = '/ride-tracking';

  final RideRequest rideRequest;

  const RideTrackingScreen({Key? key, required this.rideRequest})
    : super(key: key);

  @override
  Widget build(BuildContext context) {
    final vm = context.read<RideViewModel>();
    final origin = rideRequest.pickupLocation;
    final destination = rideRequest.dropoffLocation;

    // calcular bounds para cámara
    final sw = LatLng(
      min(origin.latitude, destination.latitude),
      min(origin.longitude, destination.longitude),
    );
    final ne = LatLng(
      max(origin.latitude, destination.latitude),
      max(origin.longitude, destination.longitude),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Seguimiento de Viaje')),
      body: Column(
        children: [
          // Mapa con marcadores y línea directa (opcional)
          Expanded(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(target: sw, zoom: 12),
              markers: {
                Marker(
                  markerId: const MarkerId('origin'),
                  position: origin,
                  infoWindow: const InfoWindow(title: 'Tu ubicación'),
                ),
                Marker(
                  markerId: const MarkerId('destination'),
                  position: destination,
                  infoWindow: const InfoWindow(title: 'Destino'),
                ),
              },
              polylines: {
                Polyline(
                  polylineId: const PolylineId('route'),
                  points: [origin, destination],
                  width: 5,
                  color: Colors.blue,
                ),
              },
              onMapCreated: (ctrl) {
                ctrl.animateCamera(
                  CameraUpdate.newLatLngBounds(
                    LatLngBounds(southwest: sw, northeast: ne),
                    60,
                  ),
                );
              },
            ),
          ),

          // Capa inferior: distancia real
          FutureBuilder<double>(
            future: vm.calculateDistance(origin, destination),
            builder: (ctx, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.all(16),
                  child: CircularProgressIndicator(),
                );
              }
              if (snap.hasError) {
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text('Error al calcular distancia: ${snap.error}'),
                );
              }
              final km = snap.data!;
              return Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Distancia estimada: ${km.toStringAsFixed(2)} km',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
